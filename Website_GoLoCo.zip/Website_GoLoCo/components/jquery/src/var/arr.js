define( function() {
	return [];
} );
